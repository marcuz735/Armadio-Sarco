import json
from Vestito import *
from Sarco import *
import tkinter as tk
from tkinter import *
scarpe = []
pantaloni = []
maglie = []
felpe = []
giacche = []

vestiti = []

data = json.load(open("scarpe.json"))
for i in data:
    valori = list(i.values())
    s = Scarpa(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    scarpe.append(s)
    
data = json.load(open("pantaloni.json"))
for i in data:
    valori = list(i.values())
    s = Pantaloni(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    pantaloni.append(s)

data = json.load(open("felpe.json"))
for i in data:
    valori = list(i.values())
    s = Felpa(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    felpe.append(s)

data = json.load(open("maglie.json"))
for i in data:
    valori = list(i.values())
    s = Maglia(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    maglie.append(s)
    
data = json.load(open("giacche.json"))
for i in data:
    valori = list(i.values())
    s = Giacca(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    giacche.append(s)
    
vestiti = [giacche,felpe,maglie,pantaloni,scarpe]

armadio = Sarco(vestiti)
armadio.OutfitStile('tuta','blu','primavera')