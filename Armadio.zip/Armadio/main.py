import json
from Vestito import *
from Sarco import *
import tkinter as tk
from tkinter import *
scarpe = []
pantaloni = []
maglie = []
felpe = []
giacche = []

vestiti = []

data = json.load(open("scarpe.json"))
for i in data:
    valori = list(i.values())
    s = Scarpa(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    scarpe.append(s)
    
data = json.load(open("pantaloni.json"))
for i in data:
    valori = list(i.values())
    s = Pantaloni(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    pantaloni.append(s)

data = json.load(open("felpe.json"))
for i in data:
    valori = list(i.values())
    s = Felpa(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    felpe.append(s)

data = json.load(open("maglie.json"))
for i in data:
    valori = list(i.values())
    s = Maglia(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    maglie.append(s)
    
data = json.load(open("giacche.json"))
for i in data:
    valori = list(i.values())
    s = Giacca(valori[0],valori[1],valori[2],valori[3], valori[4], valori[5])
    giacche.append(s)
    
vestiti = [giacche,felpe,maglie,pantaloni,scarpe]

armadio = Sarco(vestiti)

finestra = Tk() 
finestra.title('Selettore outfit')
finestra.resizable(False, False)
finestra.geometry("600x800") 

bg = PhotoImage(file = "foto generali/sfondo.png") 

canvas = Canvas( finestra, width = 600, 
                 height = 800) 
  
canvas.pack(fill = "both", expand = True) 

canvas.create_image( 0, 0, image = bg,  
                     anchor = "nw") 
  
testo1 = Label(canvas, text="Benvenuto\nscegli una modalità con cui creare un outfit.", font=("Perpetua", 20, "bold"), fg="black",bg = '#ffffcc')
testo1.pack(pady=50, padx=10, anchor="n")


def mostra_immagini(lunghezza,outfit):
    global bg,immagine,immagine1,immagine2,immagine3,immagine4
    testo1.pack_forget()
    canvas.delete("all")
    if lunghezza == 3:
        bg = PhotoImage(file = "foto generali/sfondo 3.png") 
        canvas.pack(fill = "both", expand = True)
        canvas.create_image(0, 0, image=bg, anchor="nw")
        
        immagine = PhotoImage(file=outfit[0].getFoto())
        canvas.create_image(157, 220, image=immagine,anchor='center')
        frame_testo = Frame(canvas)
        canvas.create_window(157, 365, anchor='center', window=frame_testo)
        testo5 = Label(frame_testo, text=outfit[0].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo5.pack(pady=10, padx=10)
        
        immagine1 = PhotoImage(file=outfit[1].getFoto())
        canvas.create_image(431,240,image= immagine1,anchor='center') 
        frame_testo1 = Frame(canvas)
        canvas.create_window(435, 370, anchor='center', window=frame_testo1)
        testo6 = Label(frame_testo1, text=outfit[1].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo6.pack(pady=10, padx=10)
        
        immagine2 = PhotoImage(file=outfit[2].getFoto())
        canvas.create_image(294,505,image= immagine2,anchor='center')
        frame_testo2 = Frame(canvas)
        canvas.create_window(294, 600, anchor='center', window=frame_testo2)
        testo7 = Label(frame_testo2, text=outfit[2].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo7.pack(pady=10, padx=10)
    elif lunghezza == 4:
        bg = PhotoImage(file = "foto generali/sfondo 4.png") 
        canvas.pack(fill = "both", expand = True)
        canvas.create_image(0, 0, image=bg, anchor="nw")
        
        immagine = PhotoImage(file=outfit[0].getFoto())
        canvas.create_image(157, 230, image=immagine,anchor='center') 
        frame_testo = Frame(canvas)
        canvas.create_window(157, 360, anchor='center', window=frame_testo)
        testo5 = Label(frame_testo, text=outfit[0].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo5.pack(pady=10, padx=10)
        
        immagine1 = PhotoImage(file=outfit[1].getFoto())
        canvas.create_image(435,230,image= immagine1,anchor='center') 
        frame_testo1 = Frame(canvas)
        canvas.create_window(435, 360, anchor='center', window=frame_testo1)
        testo6 = Label(frame_testo1, text=outfit[1].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo6.pack(pady=10, padx=10)
        
        immagine2 = PhotoImage(file=outfit[2].getFoto())
        canvas.create_image(157,530,image= immagine2,anchor='center')
        frame_testo2 = Frame(canvas)
        canvas.create_window(157, 630, anchor='center', window=frame_testo2)
        testo7 = Label(frame_testo2, text=outfit[2].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo7.pack(pady=10, padx=10)
        
        immagine3 = PhotoImage(file=outfit[3].getFoto())
        canvas.create_image(435,530,image= immagine3,anchor='center') 
        frame_testo3 = Frame(canvas)
        canvas.create_window(435, 630, anchor='center', window=frame_testo3)
        testo8 = Label(frame_testo3, text=outfit[3].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo8.pack(pady=10, padx=10)
    else:
        bg = PhotoImage(file = "foto generali/sfondo 5.png") 
        canvas.pack(fill = "both", expand = True)
        canvas.create_image(0, 0, image=bg, anchor="nw")
        
        immagine = PhotoImage(file=outfit[0].getFoto())
        canvas.create_image(157, 150, image=immagine,anchor='center') 
        frame_testo = Frame(canvas)
        canvas.create_window(157, 270, anchor='center', window=frame_testo)
        testo5 = Label(frame_testo, text=outfit[0].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo5.pack(pady=10, padx=10)
        
        immagine1 = PhotoImage(file=outfit[1].getFoto())
        canvas.create_image(457,150,image= immagine1,anchor='center') 
        frame_testo1 = Frame(canvas)
        canvas.create_window(457, 270, anchor='center', window=frame_testo1)
        testo6 = Label(frame_testo1, text=outfit[1].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo6.pack(pady=10, padx=10)
        
        immagine2 = PhotoImage(file=outfit[2].getFoto())
        canvas.create_image(157,405,image= immagine2,anchor='center')
        frame_testo2 = Frame(canvas)
        canvas.create_window(157, 530, anchor='center', window=frame_testo2)
        testo7 = Label(frame_testo2, text=outfit[2].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo7.pack(pady=10, padx=10)
        
        immagine3 = PhotoImage(file=outfit[3].getFoto())
        canvas.create_image(457,405,image= immagine3,anchor='center')
        frame_testo3 = Frame(canvas)
        canvas.create_window(457, 530, anchor='center', window=frame_testo3)
        testo8 = Label(frame_testo3, text=outfit[3].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo8.pack(pady=10, padx=10)
        
        immagine4 = PhotoImage(file=outfit[4].getFoto())
        canvas.create_image(307,630,image= immagine4,anchor='center') 
        frame_testo4 = Frame(canvas)
        canvas.create_window(307, 730, anchor='center', window=frame_testo4)
        testo9 = Label(frame_testo4, text=outfit[4].getNome(), font=("Perpetua", 12, "bold"), fg="black")
        testo9.pack(pady=10, padx=10)

def crea_outfit_stagione(stagione):
    testo2.pack_forget()
    outfit = armadio.OutfitStagione(stagione)
    mostra_immagini(len(outfit),outfit)
                      
def mostra_schermata_stagione():
    global testo2
    testo1.pack_forget()
    canvas.delete(button1_canvas)
    canvas.delete(button2_canvas)
    canvas.delete(button3_canvas)
    canvas.delete(button4_canvas)
    
    testo2 = Label(canvas, text="Scegli la stagione su cui basare il tuo outfit.", font=("Perpetua", 20, "bold"), fg="black", bg='#ffffcc')
    testo2.pack(pady=50, padx=10, anchor="n")
    
    button5 = Button(finestra, text="Primavera", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_stagione('primavera'))
    button6 = Button(finestra, text="Estate", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_stagione('estate'))
    button7 = Button(finestra, text="Autunno", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_stagione('autunno'))
    button8 = Button(finestra, text="Inverno", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_stagione('inverno'))
    
    button5_canvas = canvas.create_window(100, 300, anchor="nw", window=button5, width=400, height=50)
    button6_canvas = canvas.create_window(100, 400, anchor="nw", window=button6, width=400, height=50)
    button7_canvas = canvas.create_window(100, 500, anchor="nw", window=button7, width=400, height=50)
    button8_canvas = canvas.create_window(100, 600, anchor="nw", window=button8, width=400, height=50)

def crea_outfit_colore(colore):
    outfit = armadio.OutfitColore(colore)
    testo3.pack_forget()
    mostra_immagini(len(outfit),outfit)
    
def mostra_schermata_colore():
    global testo3
    testo1.pack_forget()
    canvas.delete(button1_canvas)
    canvas.delete(button2_canvas)
    canvas.delete(button3_canvas)
    canvas.delete(button4_canvas)
    
    testo3 = Label(canvas, text="Scegli il colore su cui basare il tuo outfit.", font=("Perpetua", 20, "bold"), fg="black",bg = '#ffffcc')
    testo3.pack(pady=50, padx=10, anchor="n")
    button5 = Button(finestra, text="Bianco", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_colore('bianco'))
    button6 = Button(finestra, text="Nero", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_colore('nero'))
    button7 = Button(finestra, text="Rosso", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_colore('rosso'))
    button8 = Button(finestra, text="Blu", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_colore('blu'))
    button9 = Button(finestra, text="Giallo", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=lambda: crea_outfit_colore('giallo'))
    
    button5_canvas = canvas.create_window(100, 200, anchor="nw", window=button5, width=400, height=50)
    button6_canvas = canvas.create_window(100, 300, anchor="nw", window=button6, width=400, height=50)
    button7_canvas = canvas.create_window(100, 400, anchor="nw", window=button7, width=400, height=50)
    button8_canvas = canvas.create_window(100, 500, anchor="nw", window=button8, width=400, height=50)
    button9_canvas = canvas.create_window(100, 600, anchor="nw", window=button9, width=400, height=50)

def crea_outfit_stile():
    stagione = menu_stagione.get()
    colore = menu_colore.get()
    stile = menu_stile.get()
    outfit = armadio.OutfitStile(stile,colore,stagione)
    testo4.pack_forget()
    mostra_immagini(len(outfit),outfit)
        
def mostra_schermata_stile():
    global menu_stagione,menu_colore,menu_stile,testo4
    
    testo1.pack_forget()
    canvas.delete(button1_canvas)
    canvas.delete(button2_canvas)
    canvas.delete(button3_canvas)
    canvas.delete(button4_canvas)
    
    testo4 = Label(canvas, text="Fai le tue scelte.", font=("Perpetua", 20, "bold"), fg="black",bg = '#ffffcc')
    testo4.pack(pady=50, padx=10, anchor="n")

    stagioni = ["inverno", "primavera", "estate", "autunno"]
    menu_stagione = StringVar(finestra)
    menu_stagione.set(stagioni[0])
    menu_stagione_tendina = OptionMenu(canvas, menu_stagione, *stagioni)
    menu_stagione_tendina.config(bg='#ffffcc', font=("Perpetua", 20, "bold"), width=10)
    canvas.create_window(100, 300,anchor='nw', window=menu_stagione_tendina, width=400, height=50)

    colori = ["rosso", "giallo", "blu"]
    menu_colore = StringVar(finestra)
    menu_colore.set(colori[0])
    menu_colore_tendina = OptionMenu(canvas, menu_colore, *colori)
    menu_colore_tendina.config(bg='#ffffcc', font=("Perpetua", 20, "bold"), width=10)
    canvas.create_window(100, 400,anchor='nw', window=menu_colore_tendina, width=400, height=50)

    stili = ["tuta", "elegante", "casual"]
    menu_stile = StringVar(finestra)
    menu_stile.set(stili[0])
    menu_stile_tendina = OptionMenu(canvas, menu_stile, *stili)
    menu_stile_tendina.config(bg='#ffffcc', font=("Perpetua", 20, "bold"), width=10)
    canvas.create_window(100, 500,anchor='nw', window=menu_stile_tendina, width=400, height=50)

    conferma = Button(finestra, text='CREA OUTFIT', bg="#ffffcc", font=("Perpetua", 18, "bold"), command=crea_outfit_stile)
    canvas.create_window(100, 600,anchor='nw', window=conferma, width=400, height=50)
    
def crea_outfit_casuale():
    outfit = armadio.OutfitCasuale()
    mostra_immagini(len(outfit),outfit)
    
button1 = Button(finestra, text="STAGIONE", bg="#ffffcc", font=("Perpetua", 18, "bold"), command=mostra_schermata_stagione)
button2 = Button(finestra, text="COLORE", bg="#ffffcc", font=("Perpetua", 18, "bold"),command=mostra_schermata_colore)
button3 = Button(finestra, text="COLORE, STAGIONE E STILE", bg="#ffffcc", font=("Perpetua", 18, "bold"),command=mostra_schermata_stile)
button4 = Button(finestra, text="CASUALE", bg="#ffffcc", font=("Perpetua", 18, "bold"),command=crea_outfit_casuale)

button1_canvas = canvas.create_window(100, 300, anchor="nw", window=button1, width=400, height=50)
button2_canvas = canvas.create_window(100, 400, anchor="nw", window=button2, width=400, height=50)
button3_canvas = canvas.create_window(100, 500, anchor="nw", window=button3, width=400, height=50)
button4_canvas = canvas.create_window(100, 600, anchor="nw", window=button4, width=400, height=50)

finestra.mainloop()