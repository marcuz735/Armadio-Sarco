import random
from Vestito import *
class Sarco:
    def __init__(self,vestiti):
        self.__vestiti = vestiti
        
    def getVestiti(self):
        return self.__vestiti
    
    def OutfitStagione(self,stagione):
        outfit = []
        flag = False
        for i in self.__vestiti[0]:
            random.shuffle(self.__vestiti[0])
            if stagione in i.getStagione():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[0])
            for i in self.__vestiti[0]:
                if i.getStagione() == 'tutto':
                    outfit.append(i)

        flag = False
        for i in self.__vestiti[1]:
            random.shuffle(self.__vestiti[1])
            if stagione in i.getStagione():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[1])
            for i in self.__vestiti[1]:
                if i.getStagione() == 'tutto':
                    outfit.append(i)
                    
        flag = False
        for i in self.__vestiti[2]:
            random.shuffle(self.__vestiti[2])
            if stagione in i.getStagione():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[2])
            for i in self.__vestiti[2]:
                if i.getStagione() == 'tutto':
                    outfit.append(i)
                    
        flag = False
        for i in self.__vestiti[3]:
            random.shuffle(self.__vestiti[3])
            if stagione in i.getStagione():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[3])
            for i in self.__vestiti[3]:
                if i.getStagione() == 'tutto':
                    outfit.append(i)
                    
        flag = False
        for i in self.__vestiti[4]:
            random.shuffle(self.__vestiti[4])
            if stagione in i.getStagione():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[4])
            for i in self.__vestiti[4]:
                if i.getStagione() == 'tutto':
                    outfit.append(i)

        count = {}

        nuovo_outfit = []

        for i in outfit:
            nomeclasse = i.__class__.__name__
            if nomeclasse not in count:
                count[nomeclasse] = 0
            if count[nomeclasse] == 0:
                nuovo_outfit.append(i)
                count[nomeclasse] += 1
        outfit = nuovo_outfit
        return outfit
    
    def OutfitColore(self,colore):
        outfit = []
        flag = False
        for i in self.__vestiti[0]:
            random.shuffle(self.__vestiti[0])
            if colore in i.getColore():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[0])
            for i in self.__vestiti[0]:
                if i.getColore() == 'bianco' or i.getColore() == 'nero':
                    outfit.append(i)

        flag = False
        for i in self.__vestiti[1]:
            random.shuffle(self.__vestiti[1])
            if colore in i.getColore():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[1])
            for i in self.__vestiti[1]:
                if i.getColore() == 'bianco' or i.getColore() == 'nero':
                    outfit.append(i)
                    
        flag = False
        for i in self.__vestiti[2]:
            random.shuffle(self.__vestiti[2])
            if colore in i.getColore():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[2])
            for i in self.__vestiti[2]:
                if i.getColore() == 'bianco' or i.getColore() == 'nero':
                    outfit.append(i)
                    
        flag = False
        for i in self.__vestiti[3]:
            random.shuffle(self.__vestiti[3])
            if colore in i.getColore():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[3])
            for i in self.__vestiti[3]:
                if i.getColore() == 'bianco' or i.getColore() == 'nero':
                    outfit.append(i)
                    
        flag = False
        for i in self.__vestiti[4]:
            random.shuffle(self.__vestiti[4])
            if colore in i.getColore():
                outfit.append(i)
                flag = True
        if flag == False:
            random.shuffle(self.__vestiti[4])
            for i in self.__vestiti[4]:
                if i.getColore() == 'bianco' or i.getColore() == 'nero':
                    outfit.append(i)

        count = {}

        nuovo_outfit = []

        for i in outfit:
            nomeclasse = i.__class__.__name__
            if nomeclasse not in count:
                count[nomeclasse] = 0
            if count[nomeclasse] == 0:
                nuovo_outfit.append(i)
                count[nomeclasse] += 1
        outfit = nuovo_outfit
        return outfit

    def OutfitStile(self,stile,colore,stagione):
        outfit = []
        outfit1 = []
        outfit2 = []
        for i in self.__vestiti:
            for j in i:
                if j.getColore() == colore or j.getColore() == 'bianco' or j.getColore() == 'nero':
                    outfit.append(j)
                    
        for i in outfit:
            if stagione in i.getStagione() or i.getStagione() == 'tutto':
                outfit1.append(i)
                    
        for i in outfit1:
            if stile in i.getStile() or i.getStile() == 'tutto':
                outfit2.append(i)
        

        count = {}

        nuovo_outfit = []

        for i in outfit2:
            nomeclasse = i.__class__.__name__
            if nomeclasse not in count:
                count[nomeclasse] = 0
            if count[nomeclasse] == 0:
                nuovo_outfit.append(i)
                count[nomeclasse] += 1
        outfit = nuovo_outfit
        return outfit
    
    def OutfitCasuale(self):
        outfit = []
        for i in self.__vestiti:
            outfit.append(random.choice(i))
            
        return outfit
    