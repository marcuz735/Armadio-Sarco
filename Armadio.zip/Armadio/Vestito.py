class Vestito():
    def __init__(self, nome, colore, stile, stagione, foto):
        self.__nome = nome
        self.__colore = colore
        self.__stile = stile
        self.__stagione = stagione
        self.__foto = foto
        
    def getNome(self):
        return self.__nome
    
    def getColore(self):
        return self.__colore
    
    def getStile(self):
        return self.__stile
    
    def getStagione(self):
        return self.__stagione
    
    def getFoto(self):
        return self.__foto
    
class Scarpa(Vestito):
    def __init__(self, nome, colore, stile, stagione, foto, tipo):
        super().__init__(nome, colore, stile, stagione, foto)
        self.__tipo = tipo
        
    def getTipo(self):
        return self.__tipo

class Pantaloni(Vestito):
    def __init__(self, nome, colore, stile, stagione, foto, tipo):
        super().__init__(nome, colore, stile, stagione, foto)
        self.__tipo = tipo
        
    def getTipo(self):
        return self.__tipo
    
class Maglia(Vestito):
    def __init__(self, nome, colore, stile, stagione, foto, tipo):
        super().__init__(nome, colore, stile, stagione, foto)
        self.__tipo = tipo
        
    def getTipo(self):
        return self.__tipo
    
class Felpa(Vestito):
    def __init__(self, nome, colore, stile, stagione, foto, tipo):
        super().__init__(nome, colore, stile, stagione, foto)
        self.__tipo = tipo
        
    def getTipo(self):
        return self.__tipo
    
class Giacca(Vestito):
    def __init__(self, nome, colore, stile, stagione, foto, tipo):
        super().__init__(nome, colore, stile, stagione, foto)
        self.__tipo = tipo
        
    def getTipo(self):
        return self.__tipo